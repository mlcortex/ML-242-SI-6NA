# README

**Nome Completo:** [Aline Kessy Maciel de Oliveira]

**Área de Interesse:** [Em dúvida ainda sobre a área]

**Informações Relevantes:**
- [Recifene, filha de uma Pernambucana e um Carioca, cursando Sistemas de Informação. Além disso, gosto de bordar, caminhar, fotografar, ler e assistir filmes e séries.]
