# Nome Completo: HUGO NINO LACERDA

## Área de Interesse: Dados e Backend


## Informações Relevantes: Atualmente trabalhando como vendedor de passagens aéreas mas com interesse em fazer migração de carreira
