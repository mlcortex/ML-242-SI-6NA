# Nome Completo: Guilherme Kauã Diniz Cabral

## Matrícula
01549420

## Área de Interesse
Linux, CLI, CiberSecurity, RPA

## Informações Relevantes
Estagiário RPA, Eclesiastes 12:13-14