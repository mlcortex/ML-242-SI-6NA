# Nome Completo: Eduardo Pereira da Silva

## Matrícula
01558226

## Área de Interesse
CyberSecurity, Gestão de TI e automação/RPA

## Informações Relevantes
Estagiário de gestão e infraestrutura de TI, com um inglês duvidoso e um apaixonado pelo carnaval 🦀