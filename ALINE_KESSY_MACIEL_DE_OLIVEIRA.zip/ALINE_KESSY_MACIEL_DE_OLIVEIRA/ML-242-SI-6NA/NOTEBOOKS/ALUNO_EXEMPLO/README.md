# Nome Completo: Aluno Exemplo 1

## Área de Interesse
Física e química

## Informações Relevantes
Sou aluno de ADS e pretendo trabalhar com dados relacionados com química e fisica. 
